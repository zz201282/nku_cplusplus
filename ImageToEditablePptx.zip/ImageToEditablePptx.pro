QT += widgets gui

CONFIG += c++17

TARGET = ImageToEditablePptx
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    pptxexporter.cpp \
    zipwriter.cpp

HEADERS += \
    mainwindow.h \
    pptxexporter.h \
    zipwriter.h
